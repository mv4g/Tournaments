 "use client";

import { useMemo, useState, useEffect } from "react";
import { uiText, isRtl, languages as languageOptions } from "./i18n";
import {
  Activity, ArrowUpRight, CalendarDays, ChevronDown, CircleHelp, Crown,
  Gamepad2, LayoutDashboard, LogOut, Menu, Plus, Search, Settings, ShieldCheck,
  Swords, Trophy, Users, X, Image as ImageIcon, Check, Clock3, Bell, Zap,
  Target, Radio, Medal, Sparkles, ChevronRight, MoreHorizontal, Command,
  CircleDot, TrendingUp, Flame, Eye, SlidersHorizontal, Download, Palette,
  Copy, ExternalLink, RefreshCw, Filter, Calendar, Hash, Star, Gauge, Timer
} from "lucide-react";

type Tournament = {
  id: string | number; name: string; mode: string; map: string; date: string;
  status: "Live" | "Upcoming" | "Completed"; players: number; prize: string; color: string;
};

const initialTournaments: Tournament[] = [];

const activity: { icon: typeof Users; color: string; title: string; detail: string; time: string }[] = [];

export default function Dashboard() {
  const [active, setActive] = useState("Dashboard");
  const [language, setLanguage] = useState("en");
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All");
  const [tournaments, setTournaments] = useState<Tournament[]>(initialTournaments);
  const [databaseReady, setDatabaseReady] = useState(false);
  const [databaseLoading, setDatabaseLoading] = useState(true);
  const [liveStats, setLiveStats] = useState({ tournaments: 0, players: 0, matches: 0, prizePool: 0 });
  const [discordUser, setDiscordUser] = useState<{id:string; username:string} | null>(null);
  const [adminAllowed, setAdminAllowed] = useState(false);
  const [accessStatus, setAccessStatus] = useState<"checking" | "unconfigured" | "login" | "denied" | "allowed">("checking");
  const [showCreate, setShowCreate] = useState(false);
  const [showCover, setShowCover] = useState(false);
  const [name, setName] = useState("");
  const [mode, setMode] = useState("1v1");
  const [map, setMap] = useState("Block Dash");
  const [coverTitle, setCoverTitle] = useState("STUMBLE LABS TOURNAMENT");
  const [coverSubtitle, setCoverSubtitle] = useState("STUMBLE LABS · TOURNAMENT");
  const [coverColor, setCoverColor] = useState("#9b7bff");
  const [notice, setNotice] = useState("");
  const [mobileNav, setMobileNav] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [clock, setClock] = useState("21:04:32");
  const [reducedMotion, setReducedMotion] = useState(false);
  const [activeTab, setActiveTab] = useState("all");

  useEffect(() => {
    try { const saved = window.localStorage.getItem("stumble-labs-language"); if (saved && languages.some(([code]) => code === saved)) setLanguage(saved); } catch {}
  }, []);

  useEffect(() => {
    try { window.localStorage.setItem("stumble-labs-language", language); } catch {}
  }, [language]);

  useEffect(() => {
    const tick = () => setClock(new Date().toLocaleTimeString("en-GB", { hour12: false }));
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    let alive = true;
    const loadData = () => fetch("/api/tournaments", { cache: "no-store" })
      .then(async (response) => ({ response, payload: await response.json() }))
      .then(({ response, payload }) => {
        if (!alive) return;
        setDatabaseReady(Boolean(payload.configured) && response.ok);
        if (payload.stats) setLiveStats({ tournaments: Number(payload.stats.tournaments ?? 0), players: Number(payload.stats.players ?? 0), matches: Number(payload.stats.matches ?? 0), prizePool: Number(payload.stats.prizePool ?? 0) });
        if (response.ok && Array.isArray(payload.tournaments)) {
          setTournaments(payload.tournaments.map((row: any) => ({
            id: row.id, name: row.name, mode: row.mode, map: row.map,
            date: row.starts_at ? new Date(row.starts_at).toLocaleString(language) : uiText(language, "notScheduled"),
            status: row.status, players: Number(row.player_count ?? 0),
            prize: Number(row.prize_pool ?? 0) ? String(row.prize_pool) : "0",
            color: "#9b7bff"
          })));
        }
      })
      .catch(() => { if (alive) setDatabaseReady(false); })
      .finally(() => { if (alive) setDatabaseLoading(false); });
    loadData();
    const refreshId = window.setInterval(loadData, 30000);
    fetch("/api/admin-check", { cache: "no-store" }).then(r => r.json()).then(payload => {
      if (!alive) return;
      setAdminAllowed(Boolean(payload.allowed));
      if (payload.user) setDiscordUser(payload.user);
      setAccessStatus(!payload.configured ? "unconfigured" : !payload.authenticated ? "login" : payload.allowed ? "allowed" : "denied");
    }).catch(() => { if (alive) setAccessStatus("unconfigured"); });
    return () => { alive = false; window.clearInterval(refreshId); };
  }, [language]);

  const visible = useMemo(() => tournaments.filter(t =>
    (filter === "All" || t.status === filter) &&
    (t.name.toLowerCase().includes(query.toLowerCase()) || t.mode.toLowerCase().includes(query.toLowerCase()) || t.map.toLowerCase().includes(query.toLowerCase()))
  ), [tournaments, filter, query]);

  function flash(message: string) {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 4500);
  }

  async function createTournament() {
    if (!name.trim()) return;
    try {
      const response = await fetch("/api/tournaments", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), mode, map })
      });
      const payload = await response.json();
      if (!response.ok) {
        if (response.status === 403) flash("NO PERMISSION · Sign in with an approved Discord account.");
        else if (payload.error === "DATABASE_NOT_CONFIGURED") flash("Database is not configured yet. No local fake record was created.");
        else flash("Could not save tournament. Check the database setup and try again.");
        return;
      }
      const row = payload.tournament;
      setTournaments((current) => [{ id: row.id, name: row.name, mode: row.mode, map: row.map, date: uiText(language, "notScheduled"), status: row.status, players: row.player_count, prize: String(row.prize_pool ?? 0), color: "#9b7bff" }, ...current]);
      setLiveStats((current) => ({ ...current, tournaments: current.tournaments + 1 }));
      setName(""); setShowCreate(false); setActive("Tournaments");
      flash("Tournament saved to the live database.");
    } catch { flash("Database connection failed. No local fake record was created."); }
  }

  function downloadCover() {
    const canvas = document.createElement("canvas"); canvas.width = 1200; canvas.height = 630;
    const ctx = canvas.getContext("2d"); if (!ctx) return;
    const g = ctx.createLinearGradient(0, 0, 1200, 630);
    g.addColorStop(0, "#0b0b15"); g.addColorStop(.48, "#242047"); g.addColorStop(1, coverColor);
    ctx.fillStyle = g; ctx.fillRect(0, 0, 1200, 630);
    for (let i=0;i<18;i++) { ctx.strokeStyle = "rgba(255,255,255,.07)"; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(100+(i*89)%1150, 80+(i*137)%560, 30+(i%5)*23, 0, Math.PI*2); ctx.stroke(); }
    ctx.fillStyle = coverColor; ctx.fillRect(78, 88, 7, 450);
    ctx.fillStyle = "#fff"; ctx.font = "bold 24px Arial"; ctx.fillText(coverSubtitle.toUpperCase().slice(0,50), 118, 160);
    ctx.font = "bold 74px Arial"; ctx.fillText(coverTitle.toUpperCase().slice(0,34), 118, 290, 1000);
    ctx.font = "bold 27px Arial"; ctx.fillStyle = "#e4dcff"; ctx.fillText(`${mode.toUpperCase()}  /  ${map.toUpperCase()}`, 118, 360);
    ctx.font = "20px Arial"; ctx.fillStyle = "#fff"; ctx.fillText("STUMBLE LABS  •  OFFICIAL TOURNAMENT", 118, 535);
    const link = document.createElement("a"); link.download = "stumble-labs-tournament-cover.png"; link.href = canvas.toDataURL("image/png"); link.click();
    flash("Your 1200 × 630 tournament cover has been exported.");
  }

  const languages = languageOptions;
  const tx = (key: Parameters<typeof uiText>[1]) => uiText(language, key);
  const copy: Record<string, {stats:string; dashboard:string; tournaments:string; profile:string; leaderboard:string; lobby:string; tagline:string; explore:string; noData:string; format:string}> = {
    en:{stats:"Statistics",dashboard:"Dashboard",tournaments:"Tournaments",profile:"Profile",leaderboard:"Leaderboard",lobby:"Your next victory starts here.",tagline:"A home for competitive Stumble Guys.",explore:"Explore tournaments",noData:"No verified live data yet",format:"Match formats"},
    es:{stats:"Estadísticas",dashboard:"Panel",tournaments:"Torneos",profile:"Perfil",leaderboard:"Clasificación",lobby:"Tu próxima victoria empieza aquí.",tagline:"Un hogar para el Stumble Guys competitivo.",explore:"Explorar torneos",noData:"Aún no hay datos verificados",format:"Modos de partida"},
    fr:{stats:"Statistiques",dashboard:"Tableau de bord",tournaments:"Tournois",profile:"Profil",leaderboard:"Classement",lobby:"Ta prochaine victoire commence ici.",tagline:"Le foyer du Stumble Guys compétitif.",explore:"Explorer les tournois",noData:"Aucune donnée vérifiée",format:"Formats de match"},
    de:{stats:"Statistiken",dashboard:"Dashboard",tournaments:"Turniere",profile:"Profil",leaderboard:"Rangliste",lobby:"Dein nächster Sieg beginnt hier.",tagline:"Die Heimat des kompetitiven Stumble Guys.",explore:"Turniere entdecken",noData:"Noch keine verifizierten Daten",format:"Spielformate"},
    it:{stats:"Statistiche",dashboard:"Dashboard",tournaments:"Tornei",profile:"Profilo",leaderboard:"Classifica",lobby:"La tua prossima vittoria inizia qui.",tagline:"La casa dello Stumble Guys competitivo.",explore:"Esplora i tornei",noData:"Nessun dato verificato",format:"Formati partita"},
    pt:{stats:"Estatísticas",dashboard:"Painel",tournaments:"Torneios",profile:"Perfil",leaderboard:"Classificação",lobby:"A tua próxima vitória começa aqui.",tagline:"A casa do Stumble Guys competitivo.",explore:"Explorar torneios",noData:"Ainda sem dados verificados",format:"Formatos de partida"},
    tr:{stats:"İstatistikler",dashboard:"Panel",tournaments:"Turnuvalar",profile:"Profil",leaderboard:"Sıralama",lobby:"Bir sonraki zaferin burada başlıyor.",tagline:"Rekabetçi Stumble Guys topluluğunun merkezi.",explore:"Turnuvaları keşfet",noData:"Henüz doğrulanmış canlı veri yok",format:"Maç modları"},
    ru:{stats:"Статистика",dashboard:"Панель",tournaments:"Турниры",profile:"Профиль",leaderboard:"Рейтинг",lobby:"Твоя следующая победа начинается здесь.",tagline:"Дом соревновательного Stumble Guys.",explore:"Смотреть турниры",noData:"Проверенных данных пока нет",format:"Форматы матчей"},
    uk:{stats:"Статистика",dashboard:"Панель",tournaments:"Турніри",profile:"Профіль",leaderboard:"Рейтинг",lobby:"Твоя наступна перемога починається тут.",tagline:"Дім змагального Stumble Guys.",explore:"Переглянути турніри",noData:"Перевірених даних поки немає",format:"Формати матчів"},
    pl:{stats:"Statystyki",dashboard:"Panel",tournaments:"Turnieje",profile:"Profil",leaderboard:"Ranking",lobby:"Twoje kolejne zwycięstwo zaczyna się tutaj.",tagline:"Dom rywalizacji w Stumble Guys.",explore:"Przeglądaj turnieje",noData:"Brak zweryfikowanych danych",format:"Tryby meczu"},
    nl:{stats:"Statistieken",dashboard:"Dashboard",tournaments:"Toernooien",profile:"Profiel",leaderboard:"Ranglijst",lobby:"Je volgende overwinning begint hier.",tagline:"De thuisbasis voor competitieve Stumble Guys.",explore:"Toernooien bekijken",noData:"Nog geen geverifieerde gegevens",format:"Wedstrijdvormen"},
    sv:{stats:"Statistik",dashboard:"Översikt",tournaments:"Turneringar",profile:"Profil",leaderboard:"Topplista",lobby:"Din nästa seger börjar här.",tagline:"Hemmet för tävlingsinriktade Stumble Guys.",explore:"Utforska turneringar",noData:"Inga verifierade data ännu",format:"Matchformat"},
    no:{stats:"Statistikk",dashboard:"Oversikt",tournaments:"Turneringer",profile:"Profil",leaderboard:"Rangering",lobby:"Din neste seier starter her.",tagline:"Hjemmet for konkurransepreget Stumble Guys.",explore:"Utforsk turneringer",noData:"Ingen bekreftede data ennå",format:"Kampformater"},
    da:{stats:"Statistik",dashboard:"Oversigt",tournaments:"Turneringer",profile:"Profil",leaderboard:"Rangliste",lobby:"Din næste sejr starter her.",tagline:"Hjemmet for konkurrencedygtig Stumble Guys.",explore:"Udforsk turneringer",noData:"Ingen verificerede data endnu",format:"Kampformater"},
    fi:{stats:"Tilastot",dashboard:"Koontinäyttö",tournaments:"Turnaukset",profile:"Profiili",leaderboard:"Tulostaulukko",lobby:"Seuraava voittosi alkaa tästä.",tagline:"Kilpailullisen Stumble Guysin koti.",explore:"Selaa turnauksia",noData:"Vahvistettuja tietoja ei vielä ole",format:"Ottelumuodot"},
    el:{stats:"Στατιστικά",dashboard:"Πίνακας",tournaments:"Τουρνουά",profile:"Προφίλ",leaderboard:"Κατάταξη",lobby:"Η επόμενη νίκη σου ξεκινά εδώ.",tagline:"Το σπίτι του ανταγωνιστικού Stumble Guys.",explore:"Εξερεύνηση τουρνουά",noData:"Δεν υπάρχουν επαληθευμένα δεδομένα",format:"Μορφές αγώνα"},
    ro:{stats:"Statistici",dashboard:"Panou",tournaments:"Turnee",profile:"Profil",leaderboard:"Clasament",lobby:"Următoarea ta victorie începe aici.",tagline:"Casa competițiilor Stumble Guys.",explore:"Explorează turneele",noData:"Nu există date verificate",format:"Formate de meci"},
    hu:{stats:"Statisztikák",dashboard:"Vezérlőpult",tournaments:"Versenyek",profile:"Profil",leaderboard:"Ranglista",lobby:"A következő győzelmed itt kezdődik.",tagline:"A kompetitív Stumble Guys otthona.",explore:"Versenyek felfedezése",noData:"Még nincs ellenőrzött adat",format:"Meccsformátumok"},
    cs:{stats:"Statistiky",dashboard:"Přehled",tournaments:"Turnaje",profile:"Profil",leaderboard:"Žebříček",lobby:"Tvé další vítězství začíná zde.",tagline:"Domov soutěžního Stumble Guys.",explore:"Prozkoumat turnaje",noData:"Zatím žádná ověřená data",format:"Formáty zápasů"},
    sk:{stats:"Štatistiky",dashboard:"Prehľad",tournaments:"Turnaje",profile:"Profil",leaderboard:"Rebríček",lobby:"Tvoje ďalšie víťazstvo sa začína tu.",tagline:"Domov súťažného Stumble Guys.",explore:"Preskúmať turnaje",noData:"Zatiaľ žiadne overené údaje",format:"Formáty zápasov"},
    bg:{stats:"Статистика",dashboard:"Табло",tournaments:"Турнири",profile:"Профил",leaderboard:"Класация",lobby:"Следващата ти победа започва тук.",tagline:"Домът на състезателния Stumble Guys.",explore:"Разгледай турнирите",noData:"Няма потвърдени данни",format:"Формати на мачове"},
    sr:{stats:"Statistika",dashboard:"Kontrolna tabla",tournaments:"Turniri",profile:"Profil",leaderboard:"Rang lista",lobby:"Tvoja sledeća pobeda počinje ovde.",tagline:"Dom takmičarskog Stumble Guys-a.",explore:"Istraži turnire",noData:"Još nema potvrđenih podataka",format:"Formati meča"},
    hr:{stats:"Statistika",dashboard:"Nadzorna ploča",tournaments:"Turniri",profile:"Profil",leaderboard:"Ljestvica",lobby:"Tvoja sljedeća pobjeda počinje ovdje.",tagline:"Dom natjecateljskog Stumble Guysa.",explore:"Istraži turnire",noData:"Još nema potvrđenih podataka",format:"Formati meča"},
    ar:{stats:"الإحصائيات",dashboard:"لوحة التحكم",tournaments:"البطولات",profile:"الملف الشخصي",leaderboard:"لوحة المتصدرين",lobby:"انتصارك القادم يبدأ من هنا.",tagline:"موطن المنافسة في Stumble Guys.",explore:"استكشف البطولات",noData:"لا توجد بيانات موثقة بعد",format:"أنماط المباريات"},
    he:{stats:"סטטיסטיקה",dashboard:"לוח בקרה",tournaments:"טורנירים",profile:"פרופיל",leaderboard:"טבלת מובילים",lobby:"הניצחון הבא שלך מתחיל כאן.",tagline:"הבית של Stumble Guys תחרותי.",explore:"לגלות טורנירים",noData:"אין עדיין נתונים מאומתים",format:"פורמטים למשחק"},
    hi:{stats:"आँकड़े",dashboard:"डैशबोर्ड",tournaments:"टूर्नामेंट",profile:"प्रोफ़ाइल",leaderboard:"लीडरबोर्ड",lobby:"आपकी अगली जीत यहीं से शुरू होती है।",tagline:"प्रतिस्पर्धी Stumble Guys का घर।",explore:"टूर्नामेंट देखें",noData:"अभी सत्यापित डेटा नहीं है",format:"मैच प्रारूप"},
    id:{stats:"Statistik",dashboard:"Dasbor",tournaments:"Turnamen",profile:"Profil",leaderboard:"Papan Peringkat",lobby:"Kemenangan berikutnya dimulai di sini.",tagline:"Rumah bagi Stumble Guys kompetitif.",explore:"Jelajahi turnamen",noData:"Belum ada data terverifikasi",format:"Format pertandingan"},
    vi:{stats:"Thống kê",dashboard:"Bảng điều khiển",tournaments:"Giải đấu",profile:"Hồ sơ",leaderboard:"Bảng xếp hạng",lobby:"Chiến thắng tiếp theo bắt đầu tại đây.",tagline:"Ngôi nhà của Stumble Guys cạnh tranh.",explore:"Khám phá giải đấu",noData:"Chưa có dữ liệu xác minh",format:"Thể thức trận đấu"},
    th:{stats:"สถิติ",dashboard:"แดชบอร์ด",tournaments:"ทัวร์นาเมนต์",profile:"โปรไฟล์",leaderboard:"อันดับผู้เล่น",lobby:"ชัยชนะครั้งต่อไปเริ่มต้นที่นี่",tagline:"บ้านของ Stumble Guys สายแข่งขัน",explore:"ดูทัวร์นาเมนต์",noData:"ยังไม่มีข้อมูลที่ยืนยันแล้ว",format:"รูปแบบการแข่งขัน"},
    ja:{stats:"統計",dashboard:"ダッシュボード",tournaments:"トーナメント",profile:"プロフィール",leaderboard:"ランキング",lobby:"次の勝利はここから始まる。",tagline:"競技Stumble Guysのホーム。",explore:"大会を見る",noData:"確認済みデータはまだありません",format:"試合形式"}
  };
  const t = copy[language] || copy.en;
  const nav = [
    { label: t.stats, key: "Statistics", icon: Activity },
    { label: t.dashboard, key: "Dashboard", icon: LayoutDashboard },
    { label: t.tournaments, key: "Tournaments", icon: Trophy },
    { label: t.profile, key: "Profile", icon: Users },
    { label: t.leaderboard, key: "Leaderboard", icon: Medal }
  ];

  if (accessStatus !== "allowed") {
    return <main dir={isRtl(language) ? "rtl" : "ltr"} lang={language} className="app-shell access-gate"><div className="ambient ambient-one"/><div className="ambient ambient-two"/><section className="panel access-card"><div className="brand-mark"><Swords size={28}/></div><div className="footer-brand">STUMBLE <b>LABS</b></div><h1>{accessStatus === "checking" ? tx("noData") : accessStatus === "denied" ? tx("noPermission") : accessStatus === "unconfigured" ? tx("reviewSetup") : tx("noPermission")}</h1><p>{accessStatus === "checking" ? tx("noData") : accessStatus === "denied" ? tx("noPermission") : accessStatus === "unconfigured" ? tx("databaseNotConnected") : tx("connectDiscord")}</p>{accessStatus === "login" && <button className="button primary" onClick={async()=>{try{const {createBrowserClient}=await import("@supabase/ssr");const url=process.env.NEXT_PUBLIC_SUPABASE_URL;const key=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;if(!url||!key){setAccessStatus("unconfigured");return;}const supabase=createBrowserClient(url,key);const {error}=await supabase.auth.signInWithOAuth({provider:"discord",options:{redirectTo:`${window.location.origin}/auth/callback`}});if(error)flash("Discord sign-in could not start.");}catch{setAccessStatus("unconfigured");}}}>{tx("connectDiscord")}</button>}{accessStatus === "denied" && <button className="button secondary" onClick={async()=>{await fetch("/api/auth/sign-out",{method:"POST"});setDiscordUser(null);setAdminAllowed(false);setAccessStatus("login");}}>{tx("adminAccount")}</button>}{accessStatus === "unconfigured" && <p className="settings-footnote">Add the Supabase environment variables and approved Discord IDs in your deployment settings, then reload.</p>}</section></main>;
  }

  return (
    <main dir={isRtl(language) ? "rtl" : "ltr"} lang={language} className={`app-shell ${reducedMotion ? "reduce-motion" : ""}`}>
      <div className="ambient ambient-one"/><div className="ambient ambient-two"/>
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand"><div className="brand-mark"><Swords size={23}/><span className="brand-pulse"/></div><div><b>STUMBLE <em>LABS</em></b><span>{tx("tournaments").toUpperCase()} CONTROL</span></div><button className="mobile-close icon-button" onClick={() => setMobileNav(false)}><X size={18}/></button></div>
        <div className="workspace"><span className="workspace-dot"/><div><b>{tx("officialWorkspace")}</b><small>Stumble Guys · {tx("adminAccount")}</small></div><ChevronDown size={15}/></div>
        <div className="nav-label">{tx("mainMenu")}</div>
        <nav>{nav.map((item, i) => <button key={item.label} style={{animationDelay:`${i*45}ms`}} className={`nav-item ${active === item.key ? "selected" : ""}`} onClick={() => { setActive(item.key); setMobileNav(false); }}><item.icon size={18}/><span>{item.label}</span>{item.key === "Tournaments" && <span className="nav-count">{tournaments.length}</span>}{active === item.key && <span className="nav-active-dot"/>}</button>)}</nav>
        <div className="sidebar-section"><div className="nav-label">{tx("quickAccess")}</div><button className="nav-item" onClick={()=>flash("Live match center is part of the next backend integration step.")}><Radio size={18}/><span>{tx("liveMatchCenter")}</span><span className="live-mini-dot"/></button><button className="nav-item" onClick={()=>flash("Leaderboard preview selected.")}><Medal size={18}/><span>{t.leaderboard}</span></button></div>
        <div className="sidebar-bottom"><div className="season-card"><div className="season-glow"/><div className="season-top"><span><Sparkles size={13}/> SEASON 00</span><span className="season-live">{databaseReady ? "DATABASE LIVE" : "NOT CONNECTED"}</span></div><b>{tx("seasonUnavailable")}</b><p>{tx("noData")}</p><div className="season-progress"><span style={{width:"0%"}}/></div><small><b>0%</b></small></div><div className="admin-profile"><div className="avatar">A</div><div className="admin-info"><b>{tx("adminAccount")}</b><small><span className="online-dot"/> {tx("localPreview")}</small></div><button className="icon-button" title="Account menu" onClick={()=>flash("Discord sign-in activates after OAuth setup.")}><LogOut size={16}/></button></div></div>
      </aside>
      {mobileNav && <button className="scrim" aria-label="Close navigation" onClick={() => setMobileNav(false)}/>}
      <section className="main-area">
        <header className="topbar"><div className="top-brand"><span className="top-brand-mark"><Swords size={19}/></span><b>STUMBLE <em>LABS</em></b></div><nav className="top-nav">{nav.map(item=><button key={item.key} className={`top-nav-item ${active===item.key?"top-nav-selected":""}`} onClick={()=>setActive(item.key)}><item.icon size={15}/><span>{item.label}</span></button>)}</nav><div className="top-actions">{discordUser ? <button className="button secondary compact" onClick={async()=>{await fetch("/api/auth/sign-out",{method:"POST"});setDiscordUser(null);setAdminAllowed(false);flash("Signed out of Discord.");}}>{discordUser.username}{adminAllowed ? " · ADMIN" : " · NO PERMISSION"}</button> : <button className="button secondary compact" onClick={async()=>{try{const { createBrowserClient } = await import("@supabase/ssr");const url=process.env.NEXT_PUBLIC_SUPABASE_URL;const key=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;if(!url||!key){flash("Configure Supabase URL and anon key before Discord sign-in.");return;}const supabase=createBrowserClient(url,key);const {error}=await supabase.auth.signInWithOAuth({provider:"discord",options:{redirectTo:`${window.location.origin}/auth/callback`}});if(error)flash("Discord sign-in could not start.");}catch{flash("Discord sign-in is not configured yet.");}}}>{tx("connectDiscord")}</button>}<label className="language-select" title={tx("language")}><span>文</span><select aria-label={tx("language")} value={language} onChange={e=>setLanguage(e.target.value)}>{languages.map(([code,label])=><option key={code} value={code}>{label}</option>)}</select><ChevronDown size={13}/></label><div className="live-clock"><span className="clock-dot"/><span>{clock}</span><small>TRT</small></div><div className="top-divider"/><button className="icon-button command-btn" title="Keyboard shortcuts" onClick={()=>flash("Shortcuts: N creates a tournament, C opens Cover Studio. Keyboard bindings are a future enhancement.")}><Command size={17}/></button><div className="notification-wrap"><button className={`icon-button notification-btn ${notifOpen?"is-open":""}`} title="Notifications" onClick={()=>setNotifOpen(!notifOpen)}><Bell size={18}/><span/></button>{notifOpen && <div className="notification-pop"><div className="pop-heading"><b>{tx("notifications")}</b><span>0</span></div><div className="empty-state"><b>{tx("noVerifiedNotifications")}</b><span>{tx("noData")}</span></div><button className="pop-footer" onClick={()=>{setNotifOpen(false);setActive("Settings")}}>{tx("reviewSetup")} <ArrowUpRight size={13}/></button></div>}</div><div className="top-avatar">A<span/></div></div></header>
        <div className="content">
          <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> STUMBLE LABS {tx("system").toUpperCase()} <span className="eyebrow-badge"><Sparkles size={11}/> {databaseLoading ? "CHECKING DATA" : databaseReady ? "DATABASE LIVE" : tx("databaseNotConnected").toUpperCase()}</span></div><h1>{active === "Dashboard" ? <>{t.dashboard}</> : active === "Statistics" ? t.stats : active === "Tournaments" ? t.tournaments : active === "Profile" ? t.profile : active === "Leaderboard" ? t.leaderboard : active}</h1><p>{t.tagline}</p></div><div className="heading-actions"><button className="button secondary" onClick={() => setShowCover(true)}><Palette size={16}/> <span>{tx("coverStudio")}</span></button><button className="button primary" onClick={() => setShowCreate(true)}><Plus size={17}/> {tx("newTournament")} <span className="button-shortcut">N</span></button></div></div>
          {notice && <div className="notice"><span className="notice-icon"><Check size={15}/></span>{notice}<button onClick={() => setNotice("")}><X size={15}/></button></div>}
          {active === "Settings" ? <section className="panel settings-panel animate-in"><div className="section-title"><div><span className="panel-kicker">{tx("settings").toUpperCase()}</span><h2>{tx("workspaceSettings")}</h2><p>{tx("database")}</p></div></div><div className="setting-row"><div className="setting-symbol"><ShieldCheck size={20}/></div><div><b>{tx("adminAccess")}</b><p>{tx("noPermission")}</p></div><span className="pill amber">{tx("reviewSetup")}</span></div><div className="setting-row"><div className="setting-symbol"><Activity size={20}/></div><div><b>{tx("database")}</b><p>{tx("databaseNotConnected")}</p></div><span className="pill amber">{tx("databaseNotConnected")}</span></div><div className="setting-row"><div className="setting-symbol"><Gamepad2 size={20}/></div><div><b>{tx("coverStudio")}</b><p>{tx("createCover")}</p></div><span className="pill green">{tx("localPreview")}</span></div><div className="setting-row"><div className="setting-symbol"><Gauge size={20}/></div><div><b>{tx("motionEffects")}</b><p>{tx("motionEffects")}</p></div><button className={`toggle ${!reducedMotion?"toggle-on":""}`} onClick={()=>setReducedMotion(!reducedMotion)}><span/></button></div><p className="settings-footnote">This is a front-end prototype. Authentication and persistent storage activate after environment variables and database policies are configured.</p></section> : active === "Players" ? <section className="panel animate-in"><div className="section-title"><div><span className="panel-kicker">{tx("officialWorkspace").toUpperCase()}</span><h2>{tx("playerDirectory")}</h2><p>{tx("noData")}</p></div><button className="button secondary" onClick={()=>flash("Player import will be available after database integration.")}><Download size={15}/> {tx("importPlayers")}</button></div><div className="empty-state"><div className="empty-orb"><Users size={30}/></div><b>{tx("noRecords")}</b><span>{tx("databaseNotConnected")}</span></div></section> : active === "Tournaments" ? <section className="panel animate-in"><div className="section-title"><div><span className="panel-kicker">{tx("tournaments").toUpperCase()}</span><h2>{t.tournaments}</h2><p>{t.noData}. {tx("selectFormat")}.</p></div><button className="button primary" onClick={()=>setShowCreate(true)}><Plus size={16}/> {tx("newTournament")}</button></div><div className="mode-grid">{["1v1","2v2","3v3","4v4","FFA"].map((format,i)=><button key={format} className="mode-card" onClick={()=>{setMode(format);setShowCreate(true)}}><span className="mode-card-index">0{i+1}</span><b>{format}</b><small>{format==="FFA" ? tx("freeForAll") : tx("teamDuel")}</small><ArrowUpRight size={16}/></button>)}</div><div className="empty-state"><div className="empty-orb"><Trophy size={30}/></div><b>{tx("noLiveTournaments")}</b><span>{t.noData}. {tx("noData")}</span></div></section> : active === "Statistics" ? <section className="panel animate-in"><div className="section-title"><div><span className="panel-kicker">{tx("noData").toUpperCase()}</span><h2>{t.stats}</h2><p>{t.noData}</p></div></div><div className="stats-grid"><Stat icon={<Trophy size={19}/>} label={tx("tournaments")} value={String(liveStats.tournaments)} note={t.noData} tone="violet" trend={tx("noData")}/><Stat icon={<Users size={19}/>} label={tx("players")} value={String(liveStats.players)} note={t.noData} tone="blue" trend={tx("noData")}/><Stat icon={<Activity size={19}/>} label={tx("matches")} value={String(liveStats.matches)} note={t.noData} tone="green" trend={tx("noData")}/><Stat icon={<Crown size={19}/>} label={tx("prizePool")} value={String(liveStats.prizePool)} note={t.noData} tone="orange" trend={tx("noData")}/></div></section> : active === "Profile" ? <section className="panel animate-in"><div className="section-title"><div><span className="panel-kicker">{tx("profile").toUpperCase()}</span><h2>{t.profile}</h2><p>{tx("connectDiscord")}</p></div></div><div className="empty-state"><div className="empty-orb"><Users size={30}/></div><b>{tx("profileUnavailable")}</b><span>{tx("connectDiscord")}</span></div></section> : active === "Leaderboard" ? <section className="panel animate-in"><div className="section-title"><div><span className="panel-kicker">{t.leaderboard.toUpperCase()}</span><h2>{t.leaderboard}</h2><p>{tx("noData")}</p></div></div><div className="empty-state"><div className="empty-orb"><Medal size={30}/></div><b>{tx("noLeaderboardData")}</b><span>{t.noData}</span></div></section> : <>
            <div className="hero-banner animate-in"><div className="hero-grid"/><div className="hero-orbit hero-orbit-a"/><div className="hero-orbit hero-orbit-b"/><div className="hero-copy"><div className="hero-chip"><span className="hero-chip-dot"/> {t.tournaments.toUpperCase()} · {t.noData.toUpperCase()}</div><h2>{t.lobby}</h2><p>{t.tagline}</p><div className="hero-actions"><button className="hero-button" onClick={()=>setActive("Tournaments")}>{t.explore} <ArrowUpRight size={15}/></button><span><Flame size={15}/> <b>0</b> {tx("noData")}</span></div></div><div className="hero-emblem"><div className="emblem-ring ring-a"/><div className="emblem-ring ring-b"/><div className="emblem-core"><Swords size={46}/></div><span className="emblem-star star-a">✦</span><span className="emblem-star star-b">✧</span><span className="emblem-label">SL / 00</span></div><div className="hero-index">001 <span>/</span> 008</div></div>
            <div className="stats-grid">
              <Stat icon={<Trophy size={19}/>} label={tx("tournaments")} value={String(liveStats.tournaments)} note={t.noData} tone="violet" trend={t.noData} />
              <Stat icon={<Users size={19}/>} label={tx("registeredPlayers")} value={String(liveStats.players)} note={t.noData} tone="blue" trend={tx("noData")} />
              <Stat icon={<Activity size={19}/>} label={tx("live")} value={String(tournaments.filter(t=>t.status==="Live").length).padStart(2,"0")} note={t.noData} tone="green" trend={tx("noData")} />
              <Stat icon={<Crown size={19}/>} label={tx("prizePool")} value={String(liveStats.prizePool)} note={t.noData} tone="orange" trend={tx("noData")} />
            </div>
            <div className="section-row"><div><span className="panel-kicker">{tx("quickAccess").toUpperCase()}</span><h2>{tx("recentActivity")} <span className="title-count">{visible.length}</span></h2><p>{tx("recentActivity")}</p></div><div className="section-controls"><button className="icon-button filter-icon" onClick={()=>setFilter(filter==="All"?"Live":"All")} title="Toggle live filter"><SlidersHorizontal size={16}/></button><button className="button secondary compact" onClick={()=>setActive("Tournaments")}>{tx("viewAll")} <ArrowUpRight size={14}/></button></div></div>
            <section className="panel tournament-panel animate-in"><div className="table-tools"><div className="search-box"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={tx("searchPlaceholder")}/><kbd>/</kbd></div><div className="filter-tabs">{[{label:tx("all"),value:"All"},{label:tx("live"),value:"Live"},{label:tx("upcoming"),value:"Upcoming"},{label:tx("completed"),value:"Completed"}].map(f=><button key={f.value} onClick={()=>setFilter(f.value)} className={filter===f.value?"filter-active":""}>{f.label}{f.value==="Live"&&<span className="filter-live-dot"/>}</button>)}</div></div>
              <div className="table-scroll"><table><thead><tr><th>{tx("tournament").toUpperCase()}</th><th>{tx("format").toUpperCase()}</th><th>{tx("schedule").toUpperCase()}</th><th>{tx("players").toUpperCase()}</th><th>{tx("status").toUpperCase()}</th><th>{tx("prizePool").toUpperCase()}</th><th/></tr></thead><tbody>{visible.map((t,i)=><tr key={t.id} style={{animationDelay:`${i*55}ms`}}><td><div className="tournament-name"><div className="game-icon" style={{"--t-color":t.color} as React.CSSProperties}><Gamepad2 size={17}/><span/></div><div><b>{t.name}</b><small>{t.map}</small></div></div></td><td><span className="format-tag">{t.mode}</span></td><td><div className="schedule"><CalendarDays size={14}/>{t.date}</div></td><td><div className="player-count"><Users size={14}/>{t.players}<span className="player-cap">/ 64</span></div></td><td><span className={`status status-${t.status.toLowerCase()}`}><i/>{t.status === "Live" ? tx("live") : t.status === "Upcoming" ? tx("upcoming") : tx("completed")}</span></td><td className="prize"><Crown size={13}/>{t.prize}</td><td><button className="row-menu" title="Tournament actions" onClick={()=>flash(`${t.name}: ${t.status} · ${t.mode} · ${t.players} players.`)}><MoreHorizontal size={18}/></button></td></tr>)}</tbody></table></div>
              {visible.length===0 && <div className="empty-state">{tx("noTournamentMatches")}</div>}
              <div className="table-footer"><span>{tx("viewAll")} <b>{visible.length}</b> / {tournaments.length} {tx("tournaments")}</span><span><span className="footer-dot"/> {databaseLoading ? "Checking database…" : databaseReady ? "Live database connected" : "Live database · not connected"}</span></div>
            </section>
            <div className="bottom-grid"><section className="panel quick-panel animate-in"><div className="section-title"><div><span className="panel-kicker">{tx("quickAccess").toUpperCase()}</span><h2>{tx("quickActions")}</h2><p>{tx("quickAccess")}</p></div><span className="section-icon"><Zap size={17}/></span></div><button className="quick-action" onClick={()=>setShowCreate(true)}><span className="quick-icon violet"><Plus size={18}/></span><span><b>{tx("createTournament")}</b><small>{tx("selectFormat")}</small></span><ArrowUpRight size={16}/></button><button className="quick-action" onClick={()=>setShowCover(true)}><span className="quick-icon blue"><ImageIcon size={18}/></span><span><b>{tx("createCover")}</b><small>{tx("exportPng")}</small></span><ArrowUpRight size={16}/></button><button className="quick-action" onClick={()=>setActive("Players")}><span className="quick-icon green"><Users size={18}/></span><span><b>{tx("playerDirectory")}</b><small>{tx("noRecords")}</small></span><ArrowUpRight size={16}/></button></section>
            <section className="panel activity-panel animate-in"><div className="section-title"><div><span className="panel-kicker">{tx("recentActivity").toUpperCase()}</span><h2>{tx("recentActivity")}</h2><p>{tx("noData")}</p></div><span className="feed-live"><span/> {tx("noData").toUpperCase()}</span></div><div className="activity-tabs">{[{key:"all",label:tx("allActivity")},{key:"system",label:tx("system")}].map(item=><button className={activeTab===item.key?"active":""} key={item.key} onClick={()=>setActiveTab(item.key)}>{item.label}</button>)}</div><div className="activity-list">{activity.filter(a=>activeTab==="all"||a.color==="green").map((a,i)=><div className="activity-item" key={a.title} style={{animationDelay:`${i*90}ms`}}><div className={`activity-icon ${a.color}`}><a.icon size={15}/></div><div className="activity-text"><b>{a.title}</b><small>{a.detail}</small></div><time>{a.time}</time></div>)}</div><button className="activity-footer" onClick={()=>flash("No activity records are available. The live activity feed is not connected yet.")}>{tx("recentActivity")} <ArrowUpRight size={14}/></button></section></div>
            <div className="bottom-banner"><div className="bottom-banner-icon"><ShieldCheck size={20}/></div><div><b>{tx("officialWorkspace")}</b><span>{tx("noPermission")}</span></div><button onClick={()=>setActive("Settings")}>{tx("reviewSetup")} <ChevronRight size={15}/></button><div className="banner-shine"/></div>
          </>}
          <footer><span className="footer-brand">STUMBLE <b>LABS</b></span><span className="footer-sep">/</span> {tx("tournaments").toUpperCase()} <span className="footer-right"><span className="online-dot"/> {tx("system").toUpperCase()} <span className="footer-version">BUILD 0.3.0</span></span></footer>
        </div>
      </section>
      {showCreate && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setShowCreate(false)}}><section className="modal modal-enter"><div className="modal-heading"><div><span className="eyebrow">{tx("newTournament").toUpperCase()} / 001</span><h2>{tx("createTournament")}</h2><p>{t.tagline}</p></div><button className="icon-button" onClick={()=>setShowCreate(false)}><X size={18}/></button></div><label>{tx("tournamentName")}<input autoFocus value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Friday Night Finals"/></label><div className="form-two"><label>{tx("format")}<select value={mode} onChange={e=>setMode(e.target.value)}><option>1v1</option><option>2v2</option><option>3v3</option><option>4v4</option><option>FFA</option></select></label><label>{tx("featuredMap")}<select value={map} onChange={e=>setMap(e.target.value)}><option>Block Dash</option><option>Laser Tracer</option><option>Super Slide</option><option>Turbo Temple</option><option>Honey Drop</option></select></label></div><div className="modal-note"><CalendarDays size={16}/> {tx("saveToDatabase")}. {tx("databaseNotConnected")}.</div><div className="modal-actions"><button className="button secondary" onClick={()=>setShowCreate(false)}>{tx("cancel")}</button><button className="button primary" onClick={createTournament} disabled={!name.trim()}><Plus size={16}/> {tx("save")}</button></div></section></div>}
      {showCover && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setShowCover(false)}}><section className="modal cover-modal modal-enter"><div className="modal-heading"><div><span className="eyebrow">{tx("createCover").toUpperCase()}</span><h2>{tx("coverStudio")} <Sparkles size={17}/></h2><p>{tx("createCover")}</p></div><button className="icon-button" onClick={()=>setShowCover(false)}><X size={18}/></button></div><div className="cover-preview" style={{background:`linear-gradient(125deg,#10101e 0%,#26204a 58%,${coverColor} 100%)`}}><div className="cover-preview-grid"/><div className="cover-orb orb-one"/><div className="cover-orb orb-two"/><div className="cover-content"><span>{coverSubtitle || "STUMBLE GUYS · TOURNAMENT"}</span><h3>{coverTitle || "YOUR TOURNAMENT"}</h3><b>{mode.toUpperCase()} / {map.toUpperCase()}</b><small>STUMBLE LABS · OFFICIAL TOURNAMENT</small></div><div className="cover-preview-badge"><Swords size={23}/></div></div><label>{tx("tournamentName")}<input value={coverTitle} onChange={e=>setCoverTitle(e.target.value)} maxLength={34}/></label><label>{"Subtitle"}<input value={coverSubtitle} onChange={e=>setCoverSubtitle(e.target.value)} maxLength={50}/></label><div className="form-two"><label>{tx("format")}<select value={mode} onChange={e=>setMode(e.target.value)}><option>1v1</option><option>2v2</option><option>3v3</option><option>4v4</option><option>FFA</option></select></label><label>{tx("map")}<select value={map} onChange={e=>setMap(e.target.value)}><option>Block Dash</option><option>Laser Tracer</option><option>Super Slide</option><option>Turbo Temple</option><option>Honey Drop</option></select></label></div><label>{uiText(language, "accentColor")}<div className="color-row">{["#9b7bff","#00d6b4","#ff8a4c","#ff4f89","#4a9cff","#f4cf62"].map(c=><button key={c} className={`color-swatch ${coverColor===c?"swatch-selected":""}`} style={{background:c}} onClick={()=>setCoverColor(c)} aria-label={`Select ${c}`}/>)}</div></label><div className="modal-actions"><button className="button secondary" onClick={()=>setShowCover(false)}>{tx("close")}</button><button className="button primary" onClick={downloadCover}><Download size={16}/> {tx("exportPng")}</button></div></section></div>}
    </main>
  );
}

function Stat({icon,label,value,note,tone,trend}:{icon:React.ReactNode;label:string;value:string;note:string;tone:string;trend:string}) {
  return <div className="stat-card"><div className="stat-top"><span className={`stat-icon ${tone}`}>{icon}</span><span className={`stat-trend ${tone}`}><TrendingUp size={11}/>{trend}</span></div><span className="stat-label">{label}</span><div className="stat-value">{value}</div><div className="stat-note">{note}</div><div className="stat-bottom-line"><span style={{width:tone==="violet"?"72%":tone==="blue"?"84%":tone==="green"?"38%":"61%"}}/></div></div>;
}
