-- Stumble Labs initial production schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  discord_id text unique not null,
  username text not null,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tournaments (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  mode text not null check (mode in ('1v1','2v2','3v3','4v4','FFA')),
  map text not null,
  starts_at timestamptz,
  status text not null default 'Upcoming' check (status in ('Upcoming','Live','Completed')),
  player_count integer not null default 0 check (player_count >= 0),
  prize_pool numeric(12,2) not null default 0 check (prize_pool >= 0),
  created_by_discord_id text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  mode text not null check (mode in ('1v1','2v2','3v3','4v4','FFA')),
  status text not null default 'Upcoming' check (status in ('Upcoming','Live','Completed')),
  started_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.match_results (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  discord_id text not null,
  placement integer not null check (placement > 0),
  score integer not null default 0,
  created_at timestamptz not null default now(),
  unique (match_id, discord_id)
);

create index if not exists tournaments_status_starts_idx on public.tournaments(status, starts_at);
create index if not exists matches_status_idx on public.matches(status);
create index if not exists match_results_discord_idx on public.match_results(discord_id);

alter table public.profiles enable row level security;
alter table public.tournaments enable row level security;
alter table public.matches enable row level security;
alter table public.match_results enable row level security;

-- Public can read published competition data. Writes are performed only by the
-- server API after it validates the Discord ID against ADMIN_DISCORD_IDS.
drop policy if exists "public read profiles" on public.profiles;
drop policy if exists "public read tournaments" on public.tournaments;
drop policy if exists "public read matches" on public.matches;
drop policy if exists "public read results" on public.match_results;
create policy "public read profiles" on public.profiles for select using (true);
create policy "public read tournaments" on public.tournaments for select using (true);
create policy "public read matches" on public.matches for select using (true);
create policy "public read results" on public.match_results for select using (true);

-- No client-side insert/update/delete policies by design. Never expose service-role key.
