# Stumble Labs · Tournament Control

A Next.js 14 app for a competitive Stumble Guys tournament hub. The interface includes a responsive lobby, top navigation (`Statistics`, `Dashboard`, `Tournaments`, `Profile`, `Leaderboard`), a 30-language selector, Arabic/Hebrew right-to-left layout, selectable `1v1`, `2v2`, `3v3`, `4v4`, and `FFA` formats, and a tournament-cover PNG exporter.

## Included in this build

- A 30-locale UI dictionary for the main navigation, dashboard labels, forms, empty states, status filters, and common actions.
- Language choice is saved in the browser. Brand names, map names, game modes, and some technical identifiers remain in their original form.
- Statistics begin at zero and are populated from database counts only. There are no seeded/demo tournaments.
- Tournament listing refreshes every 30 seconds from `/api/tournaments`.
- Tournament creation writes to Supabase through a server API and refuses to create local fake records when the backend is unavailable.
- Discord OAuth login uses Supabase Auth. The dashboard is blocked until configuration is present and a signed-in Discord identity matches `ADMIN_DISCORD_IDS`.
- `NO PERMISSION` is returned for non-approved accounts. The tournament read/write API is also protected by the server-side allowlist.
- SQL schema is included at `supabase/schema.sql` for profiles, tournaments, matches, and match results.

## Setup (best done on a computer)

1. Create a Supabase project.
2. Run `supabase/schema.sql` in the Supabase SQL Editor.
3. In Supabase Authentication → Providers, enable Discord and enter the Discord OAuth Client ID and Client Secret. Configure the callback URL in the Discord Developer Portal using the callback URL shown by Supabase.
4. Copy `.env.example` to `.env.local` and set:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (server only)
   - `ADMIN_DISCORD_IDS` (comma-separated Discord user IDs allowed to enter)
5. Deploy to Vercel and add the same environment variables in Vercel Project Settings. GitHub Pages cannot run the server-side OAuth/API checks used by this build.
6. Run `npm install`, then `npm run dev` to test locally.

## Security notes

- Never put the Supabase service-role key or Discord client secret in browser code or a `NEXT_PUBLIC_` variable.
- Never commit `.env.local` or real secrets.
- The server checks the Discord identity returned by Supabase against `ADMIN_DISCORD_IDS` before allowing the dashboard and tournament API.
- Before public launch, test the provider identity field with your Supabase Discord configuration and confirm an unauthorized account sees `NO PERMISSION`.

## Current limitation

The app is prepared for live Supabase data, but it is not connected to a real project until you enter your own Supabase settings and approved Discord IDs. A production build could not be run in this environment because package installation timed out; source syntax was checked, but you should run `npm install` and `npm run build` on your computer before deployment.
