import { NextResponse } from "next/server";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
export async function POST() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (url && anon) {
    const store = cookies();
    const supabase = createServerClient(url, anon, { cookies: {
      get(name: string) { return store.get(name)?.value; },
      set(name: string, value: string, options: any) { try { store.set({ name, value, ...options }); } catch {} },
      remove(name: string, options: any) { try { store.set({ name, value: "", ...options }); } catch {} },
    }});
    await supabase.auth.signOut();
  }
  return NextResponse.json({ ok: true });
}
