import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

export const dynamic = "force-dynamic";

function adminDb() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) return null;
  return createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
}

async function getAllowedDiscordId(): Promise<string | null> {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !anon) return null;
  const cookieStore = cookies();
  const authClient = createServerClient(url, anon, {
    cookies: {
      get(name: string) { return cookieStore.get(name)?.value; },
      set(name: string, value: string, options: any) { try { cookieStore.set({ name, value, ...options }); } catch {} },
      remove(name: string, options: any) { try { cookieStore.set({ name, value: "", ...options }); } catch {} },
    },
  });
  const { data: { user } } = await authClient.auth.getUser();
  if (!user) return null;
  const identity = user.identities?.find((item) => item.provider === "discord");
  const identityData = identity?.identity_data as Record<string, unknown> | undefined;
  const discordId = String(identityData?.provider_id ?? identityData?.sub ?? identity?.id ?? user.user_metadata?.provider_id ?? "");
  const allowed = (process.env.ADMIN_DISCORD_IDS ?? "").split(",").map((id) => id.trim()).filter(Boolean);
  return discordId && allowed.includes(discordId) ? discordId : null;
}

export async function GET() {
  const discordId = await getAllowedDiscordId();
  if (!discordId) return NextResponse.json({ error: "NO_PERMISSION" }, { status: 403 });
  const db = adminDb();
  if (!db) return NextResponse.json({ configured: false, tournaments: [], stats: { tournaments: 0, players: 0, matches: 0, prizePool: 0 } }, { status: 200 });
  const [{ data, error }, tournamentCount, playerCount, matchCount] = await Promise.all([
    db.from("tournaments").select("id,name,mode,map,starts_at,status,player_count,prize_pool,created_at").order("created_at", { ascending: false }),
    db.from("tournaments").select("id", { count: "exact", head: true }),
    db.from("profiles").select("id", { count: "exact", head: true }),
    db.from("matches").select("id", { count: "exact", head: true }),
  ]);
  if (error || tournamentCount.error || playerCount.error || matchCount.error) return NextResponse.json({ configured: true, error: "DATABASE_READ_FAILED", tournaments: [], stats: { tournaments: 0, players: 0, matches: 0, prizePool: 0 } }, { status: 503 });
  const prizePool = (data ?? []).reduce((sum, row) => sum + Number(row.prize_pool ?? 0), 0);
  return NextResponse.json({ configured: true, tournaments: data ?? [], stats: { tournaments: tournamentCount.count ?? 0, players: playerCount.count ?? 0, matches: matchCount.count ?? 0, prizePool } }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const discordId = await getAllowedDiscordId();
  if (!discordId) return NextResponse.json({ error: "NO_PERMISSION" }, { status: 403 });
  const db = adminDb();
  if (!db) return NextResponse.json({ error: "DATABASE_NOT_CONFIGURED" }, { status: 503 });
  let body: any;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "INVALID_JSON" }, { status: 400 }); }
  const name = typeof body.name === "string" ? body.name.trim().slice(0, 100) : "";
  const mode = body.mode;
  const map = typeof body.map === "string" ? body.map.trim().slice(0, 80) : "";
  if (!name || !map || !["1v1", "2v2", "3v3", "4v4", "FFA"].includes(mode)) {
    return NextResponse.json({ error: "INVALID_TOURNAMENT" }, { status: 400 });
  }
  const { data, error } = await db.from("tournaments").insert({ name, mode, map, status: "Upcoming", player_count: 0, prize_pool: 0, created_by_discord_id: discordId }).select("id,name,mode,map,starts_at,status,player_count,prize_pool,created_at").single();
  if (error) return NextResponse.json({ error: "DATABASE_WRITE_FAILED" }, { status: 503 });
  return NextResponse.json({ tournament: data }, { status: 201 });
}
