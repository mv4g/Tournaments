import { NextResponse } from "next/server";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

export const dynamic = "force-dynamic";
export async function GET() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !anon) return NextResponse.json({ authenticated: false, allowed: false, configured: false });
  const store = cookies();
  const supabase = createServerClient(url, anon, { cookies: {
    get(name: string) { return store.get(name)?.value; },
    set(name: string, value: string, options: any) { try { store.set({ name, value, ...options }); } catch {} },
    remove(name: string, options: any) { try { store.set({ name, value: "", ...options }); } catch {} },
  }});
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ authenticated: false, allowed: false, configured: true });
  const identity = user.identities?.find((item) => item.provider === "discord");
  const identityData = identity?.identity_data as Record<string, unknown> | undefined;
  const discordId = String(identityData?.provider_id ?? identityData?.sub ?? identity?.id ?? user.user_metadata?.provider_id ?? "");
  const allowedIds = (process.env.ADMIN_DISCORD_IDS ?? "").split(",").map((value) => value.trim()).filter(Boolean);
  const allowed = Boolean(discordId && allowedIds.includes(discordId));
  return NextResponse.json({ authenticated: true, allowed, user: { id: discordId, username: String(user.user_metadata?.full_name ?? user.user_metadata?.name ?? user.user_metadata?.user_name ?? "Discord user") } });
}
