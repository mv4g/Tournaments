 "use client";

import { useMemo, useState, useEffect } from "react";
import {
  Activity, ArrowUpRight, CalendarDays, ChevronDown, CircleHelp, Crown,
  Gamepad2, LayoutDashboard, LogOut, Menu, Plus, Search, Settings, ShieldCheck,
  Swords, Trophy, Users, X, Image as ImageIcon, Check, Clock3, Bell, Zap,
  Target, Radio, Medal, Sparkles, ChevronRight, MoreHorizontal, Command,
  CircleDot, TrendingUp, Flame, Eye, SlidersHorizontal, Download, Palette,
  Copy, ExternalLink, RefreshCw, Filter, Calendar, Hash, Star, Gauge, Timer
} from "lucide-react";

type Tournament = {
  id: number; name: string; mode: string; map: string; date: string;
  status: "Live" | "Upcoming" | "Completed"; players: number; prize: string; color: string;
};

const initialTournaments: Tournament[] = [
  { id: 1, name: "Midnight Showdown", mode: "Elimination", map: "Laser Tracer", date: "Today · 21:00", status: "Live", players: 32, prize: "2,500 gems", color: "#9d7bff" },
  { id: 2, name: "Arena Sprint #08", mode: "Race", map: "Super Slide", date: "Tomorrow · 20:30", status: "Upcoming", players: 48, prize: "1,500 gems", color: "#58b8ff" },
  { id: 3, name: "Ranked Clash", mode: "Ranked", map: "Block Dash", date: "Oct 20 · 19:00", status: "Completed", players: 24, prize: "1,000 gems", color: "#ff9c66" },
  { id: 4, name: "Purple Circuit", mode: "Race", map: "Turbo Temple", date: "Oct 19 · 18:30", status: "Completed", players: 16, prize: "750 gems", color: "#ff66b2" }
];

const activity = [
  { icon: Users, color: "blue", title: "New player registered", detail: "NeonRider joined the arena", time: "2 min ago" },
  { icon: Trophy, color: "violet", title: "Tournament completed", detail: "Purple Circuit · winner verified", time: "18 min ago" },
  { icon: ShieldCheck, color: "green", title: "Admin action logged", detail: "Results approved by admin", time: "41 min ago" },
  { icon: Radio, color: "orange", title: "Match is live", detail: "Midnight Showdown · Round 3", time: "1 hr ago" }
];

export default function Dashboard() {
  const [active, setActive] = useState("Overview");
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All");
  const [tournaments, setTournaments] = useState(initialTournaments);
  const [showCreate, setShowCreate] = useState(false);
  const [showCover, setShowCover] = useState(false);
  const [name, setName] = useState("");
  const [mode, setMode] = useState("Race");
  const [map, setMap] = useState("Block Dash");
  const [coverTitle, setCoverTitle] = useState("MIDNIGHT SHOWDOWN");
  const [coverSubtitle, setCoverSubtitle] = useState("STUMBLE GUYS · TOURNAMENT");
  const [coverColor, setCoverColor] = useState("#9b7bff");
  const [notice, setNotice] = useState("");
  const [mobileNav, setMobileNav] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [clock, setClock] = useState("21:04:32");
  const [reducedMotion, setReducedMotion] = useState(false);
  const [activeTab, setActiveTab] = useState("All activity");

  useEffect(() => {
    const tick = () => setClock(new Date().toLocaleTimeString("en-GB", { hour12: false }));
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  const visible = useMemo(() => tournaments.filter(t =>
    (filter === "All" || t.status === filter) &&
    (t.name.toLowerCase().includes(query.toLowerCase()) || t.mode.toLowerCase().includes(query.toLowerCase()) || t.map.toLowerCase().includes(query.toLowerCase()))
  ), [tournaments, filter, query]);

  function flash(message: string) {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 4500);
  }

  function createTournament() {
    if (!name.trim()) return;
    setTournaments([{ id: Date.now(), name: name.trim(), mode, map, date: "Date not set", status: "Upcoming", players: 0, prize: "TBD", color: "#9b7bff" }, ...tournaments]);
    setName(""); setShowCreate(false); setActive("Tournaments");
    flash("Tournament draft created in this preview. Connect Supabase to save it permanently.");
  }

  function downloadCover() {
    const canvas = document.createElement("canvas"); canvas.width = 1200; canvas.height = 630;
    const ctx = canvas.getContext("2d"); if (!ctx) return;
    const g = ctx.createLinearGradient(0, 0, 1200, 630);
    g.addColorStop(0, "#0b0b15"); g.addColorStop(.48, "#242047"); g.addColorStop(1, coverColor);
    ctx.fillStyle = g; ctx.fillRect(0, 0, 1200, 630);
    for (let i=0;i<18;i++) { ctx.strokeStyle = "rgba(255,255,255,.07)"; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(100+(i*89)%1150, 80+(i*137)%560, 30+(i%5)*23, 0, Math.PI*2); ctx.stroke(); }
    ctx.fillStyle = coverColor; ctx.fillRect(78, 88, 7, 450);
    ctx.fillStyle = "#fff"; ctx.font = "bold 24px Arial"; ctx.fillText(coverSubtitle.toUpperCase().slice(0,50), 118, 160);
    ctx.font = "bold 74px Arial"; ctx.fillText(coverTitle.toUpperCase().slice(0,34), 118, 290, 1000);
    ctx.font = "bold 27px Arial"; ctx.fillStyle = "#e4dcff"; ctx.fillText(`${mode.toUpperCase()}  /  ${map.toUpperCase()}`, 118, 360);
    ctx.font = "20px Arial"; ctx.fillStyle = "#fff"; ctx.fillText("SG ARENA  •  OFFICIAL TOURNAMENT", 118, 535);
    const link = document.createElement("a"); link.download = "sg-arena-tournament-cover.png"; link.href = canvas.toDataURL("image/png"); link.click();
    flash("Your 1200 × 630 tournament cover has been exported.");
  }

  const nav = [
    { label: "Overview", icon: LayoutDashboard },
    { label: "Tournaments", icon: Trophy },
    { label: "Players", icon: Users },
    { label: "Cover Studio", icon: ImageIcon },
    { label: "Settings", icon: Settings }
  ];

  return (
    <main className={`app-shell ${reducedMotion ? "reduce-motion" : ""}`}>
      <div className="ambient ambient-one"/><div className="ambient ambient-two"/>
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand"><div className="brand-mark"><Swords size={23}/><span className="brand-pulse"/></div><div><b>SG <em>ARENA</em></b><span>TOURNAMENT CONTROL</span></div><button className="mobile-close icon-button" onClick={() => setMobileNav(false)}><X size={18}/></button></div>
        <div className="workspace"><span className="workspace-dot"/><div><b>Official Workspace</b><small>Stumble Guys · Admin</small></div><ChevronDown size={15}/></div>
        <div className="nav-label">MAIN MENU</div>
        <nav>{nav.map((item, i) => <button key={item.label} style={{animationDelay:`${i*45}ms`}} className={`nav-item ${active === item.label ? "selected" : ""}`} onClick={() => { setActive(item.label); setMobileNav(false); if(item.label === "Cover Studio") setShowCover(true); }}><item.icon size={18}/><span>{item.label}</span>{item.label === "Tournaments" && <span className="nav-count">{tournaments.length}</span>}{active === item.label && <span className="nav-active-dot"/>}</button>)}</nav>
        <div className="sidebar-section"><div className="nav-label">QUICK ACCESS</div><button className="nav-item" onClick={()=>flash("Live match center is part of the next backend integration step.")}><Radio size={18}/><span>Live match center</span><span className="live-mini-dot"/></button><button className="nav-item" onClick={()=>flash("Leaderboard preview selected.")}><Medal size={18}/><span>Leaderboard</span></button></div>
        <div className="sidebar-bottom"><div className="season-card"><div className="season-glow"/><div className="season-top"><span><Sparkles size={13}/> SEASON 08</span><span className="season-live">ACTIVE</span></div><b>Rise to the top.</b><p>Your next champion is one match away.</p><div className="season-progress"><span/></div><small><b>68%</b> season progress</small></div><div className="admin-profile"><div className="avatar">A</div><div className="admin-info"><b>Admin account</b><small><span className="online-dot"/> Local preview mode</small></div><button className="icon-button" title="Account menu" onClick={()=>flash("Discord sign-in activates after OAuth setup.")}><LogOut size={16}/></button></div></div>
      </aside>
      {mobileNav && <button className="scrim" aria-label="Close navigation" onClick={() => setMobileNav(false)}/>}
      <section className="main-area">
        <header className="topbar"><button className="mobile-menu icon-button" onClick={() => setMobileNav(true)}><Menu size={20}/></button><div className="breadcrumbs"><span className="crumb-home">SG</span><ChevronRight size={13}/> Workspace <ChevronRight size={13}/> <b>{active}</b></div><div className="top-actions"><div className="live-clock"><span className="clock-dot"/><span>{clock}</span><small>TRT</small></div><div className="top-divider"/><button className="icon-button command-btn" title="Keyboard shortcuts" onClick={()=>flash("Shortcuts: N creates a tournament, C opens Cover Studio. Keyboard bindings are a future enhancement.")}><Command size={17}/></button><div className="notification-wrap"><button className={`icon-button notification-btn ${notifOpen?"is-open":""}`} title="Notifications" onClick={()=>setNotifOpen(!notifOpen)}><Bell size={18}/><span/></button>{notifOpen && <div className="notification-pop"><div className="pop-heading"><b>Notifications</b><span>3 new</span></div><div className="pop-item"><span className="pop-icon purple"><Trophy size={15}/></span><div><b>Midnight Showdown is live</b><small>Match started 12 minutes ago</small></div></div><div className="pop-item"><span className="pop-icon blue"><Users size={15}/></span><div><b>4 new player registrations</b><small>Review player entries</small></div></div><div className="pop-item"><span className="pop-icon green"><ShieldCheck size={15}/></span><div><b>Admin security check</b><small>OAuth setup is still pending</small></div></div><button className="pop-footer" onClick={()=>{setNotifOpen(false);setActive("Settings")}}>Review system status <ArrowUpRight size={13}/></button></div>}</div><div className="top-avatar">A<span/></div></div></header>
        <div className="content">
          <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> ARENA CONTROL CENTER <span className="eyebrow-badge"><Sparkles size={11}/> SEASON 08</span></div><h1>{active === "Overview" ? <>Dashboard <span className="heading-light">overview.</span></> : active}</h1><p>Every match, every player, every moment. All under control.</p></div><div className="heading-actions"><button className="button secondary" onClick={() => setShowCover(true)}><Palette size={16}/> <span>Cover studio</span></button><button className="button primary" onClick={() => setShowCreate(true)}><Plus size={17}/> New tournament <span className="button-shortcut">N</span></button></div></div>
          {notice && <div className="notice"><span className="notice-icon"><Check size={15}/></span>{notice}<button onClick={() => setNotice("")}><X size={15}/></button></div>}
          {active === "Settings" ? <section className="panel settings-panel animate-in"><div className="section-title"><div><span className="panel-kicker">CONFIGURATION</span><h2>Workspace settings</h2><p>Core integrations for your tournament platform.</p></div></div><div className="setting-row"><div className="setting-symbol"><ShieldCheck size={20}/></div><div><b>Admin access</b><p>Only approved Discord account IDs should be allowed into this dashboard.</p></div><span className="pill amber">Setup required</span></div><div className="setting-row"><div className="setting-symbol"><Activity size={20}/></div><div><b>Database</b><p>Supabase storage for tournaments, players, results, and profiles.</p></div><span className="pill amber">Not connected</span></div><div className="setting-row"><div className="setting-symbol"><Gamepad2 size={20}/></div><div><b>Cover Studio</b><p>Built-in cover editor with PNG export.</p></div><span className="pill green">Available in preview</span></div><div className="setting-row"><div className="setting-symbol"><Gauge size={20}/></div><div><b>Motion effects</b><p>Ambient background, card entrances and hover transitions.</p></div><button className={`toggle ${!reducedMotion?"toggle-on":""}`} onClick={()=>setReducedMotion(!reducedMotion)}><span/></button></div><p className="settings-footnote">This is a front-end prototype. Authentication and persistent storage activate after environment variables and database policies are configured.</p></section> : active === "Players" ? <section className="panel animate-in"><div className="section-title"><div><span className="panel-kicker">COMMUNITY</span><h2>Player directory</h2><p>Player records will appear here once the database is connected.</p></div><button className="button secondary" onClick={()=>flash("Player import will be available after database integration.")}><Download size={15}/> Import players</button></div><div className="empty-state"><div className="empty-orb"><Users size={30}/></div><b>No player records yet</b><span>Connect Supabase to manage player profiles and statistics.</span></div></section> : <>
            <div className="hero-banner animate-in"><div className="hero-grid"/><div className="hero-orbit hero-orbit-a"/><div className="hero-orbit hero-orbit-b"/><div className="hero-copy"><div className="hero-chip"><span className="hero-chip-dot"/> LIVE SEASON · 08</div><h2>Built for the <span>next champion.</span></h2><p>Your competitive arena is moving. Keep the momentum going.</p><div className="hero-actions"><button className="hero-button" onClick={()=>setActive("Tournaments")}>Explore tournaments <ArrowUpRight size={15}/></button><span><Flame size={15}/> <b>12</b> day streak</span></div></div><div className="hero-emblem"><div className="emblem-ring ring-a"/><div className="emblem-ring ring-b"/><div className="emblem-core"><Swords size={46}/></div><span className="emblem-star star-a">✦</span><span className="emblem-star star-b">✧</span><span className="emblem-label">SG / 08</span></div><div className="hero-index">001 <span>/</span> 008</div></div>
            <div className="stats-grid">
              <Stat icon={<Trophy size={19}/>} label="Total tournaments" value={String(tournaments.length).padStart(2,"0")} note="All formats · all seasons" tone="violet" trend="+2 this week" />
              <Stat icon={<Users size={19}/>} label="Registered players" value="120" note="Sample preview data" tone="blue" trend="+12.8%" />
              <Stat icon={<Activity size={19}/>} label="Live tournaments" value={String(tournaments.filter(t=>t.status==="Live").length).padStart(2,"0")} note="Happening right now" tone="green" trend="Live now" />
              <Stat icon={<Crown size={19}/>} label="Total prize pool" value="5,750" note="Gems · sample data" tone="orange" trend="Season 08" />
            </div>
            <div className="section-row"><div><span className="panel-kicker">OPERATIONS</span><h2>Tournament activity <span className="title-count">{visible.length}</span></h2><p>Keep a close eye on every competition in your arena.</p></div><div className="section-controls"><button className="icon-button filter-icon" onClick={()=>setFilter(filter==="All"?"Live":"All")} title="Toggle live filter"><SlidersHorizontal size={16}/></button><button className="button secondary compact" onClick={()=>setActive("Tournaments")}>View all <ArrowUpRight size={14}/></button></div></div>
            <section className="panel tournament-panel animate-in"><div className="table-tools"><div className="search-box"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search tournaments, modes, maps..."/><kbd>/</kbd></div><div className="filter-tabs">{["All","Live","Upcoming","Completed"].map(f=><button key={f} onClick={()=>setFilter(f)} className={filter===f?"filter-active":""}>{f}{f==="Live"&&<span className="filter-live-dot"/>}</button>)}</div></div>
              <div className="table-scroll"><table><thead><tr><th>TOURNAMENT</th><th>FORMAT</th><th>SCHEDULE</th><th>PLAYERS</th><th>STATUS</th><th>PRIZE POOL</th><th/></tr></thead><tbody>{visible.map((t,i)=><tr key={t.id} style={{animationDelay:`${i*55}ms`}}><td><div className="tournament-name"><div className="game-icon" style={{"--t-color":t.color} as React.CSSProperties}><Gamepad2 size={17}/><span/></div><div><b>{t.name}</b><small>{t.map}</small></div></div></td><td><span className="format-tag">{t.mode}</span></td><td><div className="schedule"><CalendarDays size={14}/>{t.date}</div></td><td><div className="player-count"><Users size={14}/>{t.players}<span className="player-cap">/ 64</span></div></td><td><span className={`status status-${t.status.toLowerCase()}`}><i/>{t.status}</span></td><td className="prize"><Crown size={13}/>{t.prize}</td><td><button className="row-menu" title="Tournament actions" onClick={()=>flash(`${t.name}: ${t.status} · ${t.mode} · ${t.players} players.`)}><MoreHorizontal size={18}/></button></td></tr>)}</tbody></table></div>
              {visible.length===0 && <div className="empty-state">No tournaments match those filters.</div>}
              <div className="table-footer"><span>Showing <b>{visible.length}</b> of {tournaments.length} tournaments</span><span><span className="footer-dot"/> Preview data · not synced</span></div>
            </section>
            <div className="bottom-grid"><section className="panel quick-panel animate-in"><div className="section-title"><div><span className="panel-kicker">SHORTCUTS</span><h2>Quick actions</h2><p>Less admin. More arena.</p></div><span className="section-icon"><Zap size={17}/></span></div><button className="quick-action" onClick={()=>setShowCreate(true)}><span className="quick-icon violet"><Plus size={18}/></span><span><b>Create tournament</b><small>Set up a new competition</small></span><ArrowUpRight size={16}/></button><button className="quick-action" onClick={()=>setShowCover(true)}><span className="quick-icon blue"><ImageIcon size={18}/></span><span><b>Generate tournament cover</b><small>Design and export a 1200 × 630 PNG</small></span><ArrowUpRight size={16}/></button><button className="quick-action" onClick={()=>setActive("Players")}><span className="quick-icon green"><Users size={18}/></span><span><b>Manage player directory</b><small>Review player records and stats</small></span><ArrowUpRight size={16}/></button></section>
            <section className="panel activity-panel animate-in"><div className="section-title"><div><span className="panel-kicker">LIVE FEED</span><h2>Recent activity</h2><p>Signals from across the arena.</p></div><span className="feed-live"><span/> LIVE</span></div><div className="activity-tabs">{["All activity","System"].map(t=><button className={activeTab===t?"active":""} key={t} onClick={()=>setActiveTab(t)}>{t}</button>)}</div><div className="activity-list">{activity.filter(a=>activeTab==="All activity"||a.color==="green").map((a,i)=><div className="activity-item" key={a.title} style={{animationDelay:`${i*90}ms`}}><div className={`activity-icon ${a.color}`}><a.icon size={15}/></div><div className="activity-text"><b>{a.title}</b><small>{a.detail}</small></div><time>{a.time}</time></div>)}</div><button className="activity-footer" onClick={()=>flash("Activity feed is showing sample events until the backend is connected.")}>View activity log <ArrowUpRight size={14}/></button></section></div>
            <div className="bottom-banner"><div className="bottom-banner-icon"><ShieldCheck size={20}/></div><div><b>Your arena. Your rules.</b><span>Admin permissions and data security should be enabled before launch.</span></div><button onClick={()=>setActive("Settings")}>Review setup <ChevronRight size={15}/></button><div className="banner-shine"/></div>
          </>}
          <footer><span className="footer-brand">SG <b>ARENA</b></span><span className="footer-sep">/</span> TOURNAMENT CONTROL <span className="footer-right"><span className="online-dot"/> SYSTEM PREVIEW <span className="footer-version">BUILD 0.2.0</span></span></footer>
        </div>
      </section>
      {showCreate && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setShowCreate(false)}}><section className="modal modal-enter"><div className="modal-heading"><div><span className="eyebrow">NEW COMPETITION / 001</span><h2>Create tournament</h2><p>Every great run starts with a name.</p></div><button className="icon-button" onClick={()=>setShowCreate(false)}><X size={18}/></button></div><label>Tournament name<input autoFocus value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Friday Night Finals"/></label><div className="form-two"><label>Format<select value={mode} onChange={e=>setMode(e.target.value)}><option>Race</option><option>Elimination</option><option>Ranked</option></select></label><label>Featured map<select value={map} onChange={e=>setMap(e.target.value)}><option>Block Dash</option><option>Laser Tracer</option><option>Super Slide</option><option>Turbo Temple</option><option>Honey Drop</option></select></label></div><div className="modal-note"><CalendarDays size={16}/> This creates a local draft. Connect Supabase for permanent records.</div><div className="modal-actions"><button className="button secondary" onClick={()=>setShowCreate(false)}>Cancel</button><button className="button primary" onClick={createTournament} disabled={!name.trim()}><Plus size={16}/> Create draft</button></div></section></div>}
      {showCover && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setShowCover(false)}}><section className="modal cover-modal modal-enter"><div className="modal-heading"><div><span className="eyebrow">BUILT-IN DESIGN TOOL</span><h2>Cover Studio <Sparkles size={17}/></h2><p>Build a tournament banner that actually looks like an event.</p></div><button className="icon-button" onClick={()=>setShowCover(false)}><X size={18}/></button></div><div className="cover-preview" style={{background:`linear-gradient(125deg,#10101e 0%,#26204a 58%,${coverColor} 100%)`}}><div className="cover-preview-grid"/><div className="cover-orb orb-one"/><div className="cover-orb orb-two"/><div className="cover-content"><span>{coverSubtitle || "STUMBLE GUYS · TOURNAMENT"}</span><h3>{coverTitle || "YOUR TOURNAMENT"}</h3><b>{mode.toUpperCase()} / {map.toUpperCase()}</b><small>SG ARENA · OFFICIAL TOURNAMENT</small></div><div className="cover-preview-badge"><Swords size={23}/></div></div><label>Cover title<input value={coverTitle} onChange={e=>setCoverTitle(e.target.value)} maxLength={34}/></label><label>Subtitle<input value={coverSubtitle} onChange={e=>setCoverSubtitle(e.target.value)} maxLength={50}/></label><div className="form-two"><label>Format<select value={mode} onChange={e=>setMode(e.target.value)}><option>Race</option><option>Elimination</option><option>Ranked</option></select></label><label>Map<select value={map} onChange={e=>setMap(e.target.value)}><option>Block Dash</option><option>Laser Tracer</option><option>Super Slide</option><option>Turbo Temple</option><option>Honey Drop</option></select></label></div><label>Accent color<div className="color-row">{["#9b7bff","#00d6b4","#ff8a4c","#ff4f89","#4a9cff","#f4cf62"].map(c=><button key={c} className={`color-swatch ${coverColor===c?"swatch-selected":""}`} style={{background:c}} onClick={()=>setCoverColor(c)} aria-label={`Select ${c}`}/>)}</div></label><div className="modal-actions"><button className="button secondary" onClick={()=>setShowCover(false)}>Close</button><button className="button primary" onClick={downloadCover}><Download size={16}/> Export PNG</button></div></section></div>}
    </main>
  );
}

function Stat({icon,label,value,note,tone,trend}:{icon:React.ReactNode;label:string;value:string;note:string;tone:string;trend:string}) {
  return <div className="stat-card"><div className="stat-top"><span className={`stat-icon ${tone}`}>{icon}</span><span className={`stat-trend ${tone}`}><TrendingUp size={11}/>{trend}</span></div><span className="stat-label">{label}</span><div className="stat-value">{value}</div><div className="stat-note">{note}</div><div className="stat-bottom-line"><span style={{width:tone==="violet"?"72%":tone==="blue"?"84%":tone==="green"?"38%":"61%"}}/></div></div>;
}
