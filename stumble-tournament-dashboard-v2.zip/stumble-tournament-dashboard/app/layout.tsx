import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SG Arena | Tournament Control",
  description: "Stumble Guys tournament management dashboard"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
