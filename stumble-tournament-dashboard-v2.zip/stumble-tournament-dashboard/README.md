# SG Arena Tournament Dashboard

An animated, responsive Stumble Guys tournament-admin dashboard starter built with Next.js. Includes ambient motion, animated hero artwork, metric cards, live clock, notification dropdown, activity feed, and reduced-motion support. Includes a tournament list, draft creation, filters, settings checklist, and a built-in canvas-based cover studio that exports PNG banners.

## Important status

This repository is a **front-end starter / local preview**, not a production-secured live service yet. The dashboard currently uses sample data and in-memory state. Discord OAuth, role enforcement, and persistent Supabase CRUD must be configured before deploying for real use. Do not enter real user data into the preview.

## Requirements

- Node.js 18.18+ (Node 20 LTS recommended)
- A Supabase project
- A Discord application for OAuth
- A Vercel account

## Run locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000.

## Deployment plan

1. Push this folder to a private GitHub repository.
2. Import the repository into Vercel.
3. Create a Supabase project and configure its URL and anon key in Vercel environment variables.
4. Configure Discord OAuth in Supabase Auth (provider: Discord). Add the Supabase callback URL to the Discord Developer Portal OAuth2 redirect URLs.
5. Set `ADMIN_DISCORD_IDS` to the Discord user ID(s) allowed to administer the site.
6. Implement server-side session validation and admin authorization before enabling any write APIs.
7. Create the database tables and Row Level Security (RLS) policies below. Do not use a service-role key in browser code.

## Suggested database schema

Use Supabase SQL Editor:

```sql
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  discord_id text unique,
  display_name text,
  stumble_name text,
  stumble_id text,
  avatar_url text,
  created_at timestamptz not null default now()
);

create table public.tournaments (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  mode text not null check (mode in ('Race','Elimination','Ranked')),
  map text,
  status text not null default 'Upcoming' check (status in ('Live','Upcoming','Completed')),
  starts_at timestamptz,
  prize_pool text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.tournament_results (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete cascade,
  profile_id uuid not null references public.profiles(id) on delete cascade,
  placement integer,
  points integer not null default 0,
  created_at timestamptz not null default now(),
  unique (tournament_id, profile_id)
);

alter table public.profiles enable row level security;
alter table public.tournaments enable row level security;
alter table public.tournament_results enable row level security;

-- Start restrictive. Add policies only after implementing verified admin claims.
-- Never expose write access to anon/authenticated users just to make the UI work.
```

## Security checklist before production

- [ ] Validate Supabase sessions on the server for every protected route/action.
- [ ] Allow only explicitly configured Discord user IDs or a trusted admin claim.
- [ ] Enforce permissions in server routes and RLS, not just by hiding UI.
- [ ] Keep all secrets server-side; never commit `.env.local`.
- [ ] Add OAuth callback and sign-out flows.
- [ ] Replace all sample metrics with database queries.
- [ ] Add validation, rate limiting, audit logs, and backups.

## Current features

- Animated ambient lighting, orbit artwork, entrance transitions, hover states, and live status indicators
- Live local clock, notification panel, recent activity feed, season progress card
- Motion-reduction toggle and `prefers-reduced-motion` support


- Responsive admin dashboard
- Tournament status filters and search
- Local draft tournament creation
- Built-in title/subtitle/map/mode/accent-color cover designer
- PNG export at 1200×630
- Settings checklist for Discord and database integration

## Cover reference

The supplied `https://sitetournaments.vercel.app/` website is not copied wholesale. This project implements an original, simplified cover editor directly in the dashboard. Matching every asset or behavior requires source access or a detailed feature reference.
